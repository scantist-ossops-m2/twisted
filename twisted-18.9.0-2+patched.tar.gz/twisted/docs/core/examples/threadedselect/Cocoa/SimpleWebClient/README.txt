Requires PyObjC 1.3.1 (svn r1589 or later)

To run the demo:

pip install py2app
python setup.py py2app
open dist/Twistzilla.app
