# -*- test-case-name: calculus.test.test_base_2 -*-

from __future__ import division


class Calculation(object):
    def add(self, a, b):
        return a + b

    def subtract(self, a, b):
        return a - b

    def multiply(self, a, b):
        return a * b

    def divide(self, a, b):
        return a // b
