"""
Twisted Quotes
"""
