
:LastChangedDate: $LastChangedDate$
:LastChangedRevision: $LastChangedRevision$
:LastChangedBy: $LastChangedBy$

Twisted Mail (SMTP, POP, and IMAP)
==================================

.. toctree::
   :hidden:

   examples/index
   howto/index
   tutorial/smtpclient/smtpclient


- :doc:`Examples <examples/index>`: short code examples using Twisted Mail
- :doc:`Developer Guides <howto/index>`: documentation on using Twisted Mail
- :doc:`Twisted Mail Tutorial <tutorial/smtpclient/smtpclient>`: Building an SMTP Client from Scratch
